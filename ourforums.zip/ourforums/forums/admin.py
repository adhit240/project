from django.contrib import admin

from forums.models import Category, Topic

admin.site.register(Category)
admin.site.register(Topic)

