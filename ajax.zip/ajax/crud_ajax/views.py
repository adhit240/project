from django.shortcuts import render
from django.views.generic import ListView, View
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from jsonview.decorators import json_view
from .models import CrudUser

def index(request):
    return render(request, 'index.html')

class CrudView(ListView):
    model = CrudUser
    template_name = 'crud.html'
    context_object_name = 'users'

@method_decorator(csrf_exempt, name='dispatch')
class CreateCrudUser(View):
    def post(self, request):
        form = 
        render_crispy_form(form, context=ctx)
        return JsonResponse(data)

@method_decorator(csrf_exempt, name='dispatch')
class UpdateCrudUser(View):
    def post(self, request):
        print(request.POST)
        id1 = request.POST.get('formId', None)
        name1 = request.POST.get('name', None)
        address1 = request.POST.get('address', None)
        age1 = request.POST.get('age', None)

        obj = CrudUser.objects.get(id=id1)
        obj.name = name1
        obj.address = address1
        obj.age = age1
        obj.save()

        user = {'id':obj.id,'name':obj.name,'address':obj.address,'age':obj.age}

        data = {
            'user': user
        }
        return JsonResponse(data)

@method_decorator(csrf_exempt, name='dispatch')
class DeleteCrudUser(View):
    def post(self, request):
        id1 = request.POST.get('id', None)
        CrudUser.objects.get(id=id1).delete()
        data = {
            'deleted': True
        }
        return JsonResponse(data)